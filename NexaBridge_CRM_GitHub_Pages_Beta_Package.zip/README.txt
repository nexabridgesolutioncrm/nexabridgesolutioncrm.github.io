NexaBridge Solutions CRM — GitHub Pages Beta

Requested URL: https://nexabridgesolutioncrm.github.io/

This exact address requires GitHub account or organization `nexabridgesolutioncrm`
and repository `nexabridgesolutioncrm.github.io`.

1. Create a GitHub organization named nexabridgesolutioncrm, or use an account with that exact username.
2. Inside it, create a PUBLIC repository named nexabridgesolutioncrm.github.io.
3. Upload index.html and .nojekyll to repository root on main branch (do not upload ZIP itself).
4. Settings > Pages > Build and deployment > Deploy from a branch > main / (root).
5. Confirm site loads at https://nexabridgesolutioncrm.github.io/
6. Test sign-in with your NexaBridge Supabase Auth account and create/edit/delete a dummy CRM lead.
7. Do NOT put real customer data into the site before the login and authorization tests are completed.

Security notes: Client contains only a Supabase publishable key, not a secret/service_role key.
The public HTML is not protected by hiding the URL or robots noindex; data must remain protected by RLS.
Data is managed under the NexaBridge Solutions Supabase project.
Do not upload database passwords or service_role tokens.
